﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class ProductDetails
    {
        private string id;
        private int price;
        public string SkuID
        { 
            get
            {
                return id;
            }
            set
            {
                id = value;
            } 
        }      
    }
}
