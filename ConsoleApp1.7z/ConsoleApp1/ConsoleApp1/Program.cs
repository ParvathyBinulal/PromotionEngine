﻿using System;
using System.Collections.Generic;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Please enter the number of products");
            string input = Console.ReadLine();
            int n = Convert.ToInt32(input);
            List<ProductDetails>  products = new List<ProductDetails>();
            for(int i=1;i<=n;i++)
            {
                Console.WriteLine("Enter product SKU id");
                char id = Console.ReadLine()[0];

                ProductDetails product = new ProductDetails();
                product.SkuID = id.ToString();

                products.Add(product);

                PromotionEngine promotion = new PromotionEngine();
                int totalAmount = promotion.ApplyPromotion(products);
                Console.WriteLine("Total amount= " + totalAmount);
            }
        }
    }
}
