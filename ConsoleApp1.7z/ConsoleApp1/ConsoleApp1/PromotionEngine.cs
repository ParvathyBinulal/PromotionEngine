﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    
    class PromotionEngine
    {
        public const int priceofA = 50;
        public const int priceofB = 30;
        public const int priceofC = 20;
        public const int priceofD = 15;
        public int ApplyPromotion(List<ProductDetails> products)
        {
           int cA = 0, cB = 0, cC = 0, cD = 0;
           foreach(var product in products)
            {
                if (product.SkuID.Equals("A") || product.SkuID.Equals("a"))
                    cA++;
                if (product.SkuID.Equals("B") || product.SkuID.Equals("b"))
                    cB++;
                if (product.SkuID.Equals("A") || product.SkuID.Equals("a"))
                    cC++;
                if (product.SkuID.Equals("A") || product.SkuID.Equals("a"))
                    cD++;
            }
            int totalPriceofA = (cA / 3) * 130 + (cA % 3 * priceofA);
            int totalPriceofB = (cB / 2) * 45 + (cB % 2 * priceofB);

            int cCD;
            int totalPriceofCandD;
            
                if (cC < cD)
                    cCD = cC;
                else
                    cCD = cD;
                totalPriceofCandD = cCD * 30;
            
            int totalPriceofC = ((cC-cCD) * priceofC);
            int totalPriceofD = ((cD-cCD) * priceofD);
            return totalPriceofA + totalPriceofB + totalPriceofCandD + totalPriceofC + totalPriceofD;
        }
    }
}
